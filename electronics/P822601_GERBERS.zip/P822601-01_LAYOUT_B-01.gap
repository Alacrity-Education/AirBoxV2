! GAPFile Version 3.0
GAPFile Version 3.0 (c) 2002 DownStream Technologies
' CAM350/DFMSTREAM V12.2 (Build 1155) Date:  Fri Oct 12 16:36:13 2018
Units: Millimeters
*CAP_LIBRARY 
*END_CAP_LIBRARY

*APERTURES2 8
10  Round d:0.1599
11  Round d:0.1600
12  Round d:0.1575
13  Round d:0.0508
14  Round d:0.1599
15  Round d:0.1575
16  Round d:0.4000
17  Round d:0.0100
*END_APERTURES

