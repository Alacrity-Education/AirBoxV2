*PADS-LIBRARY-PART-TYPES-V9*

P822601 P822601 I ANA 9 1 0 0 0
TIMESTAMP 2026.08.26.20.49.24
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" P822601
"Mouser Part Number" 581-P822601
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KYOCERA-AVX/P822601?qs=vdi0iO8H4N0igrTLYxGIXg%3D%3D
"Arrow Part Number" P822601
"Arrow Price/Stock" https://www.arrow.com/en/products/p822601/avx.html?utm_currency=USD&region=europe
"Description" AVX - P822601 - EMBEDDED ANTENNA, 1.7-2.7GHZ, 3.4DBI
"Datasheet Link" http://datasheets.avx.com/ethertronics/AVX-E_P822601-P822602.pdf
"Geometry.Height" 3.5mm
GATE 1 10 0
P822601
1 0 U FEED
2 0 U GND
3 0 U DUMMY_1
4 0 U LOW_BAND_TUNING
5 0 U HIGH_BAND_TUNING_1
6 0 U DUMMY_2
7 0 U DUMMY_3
8 0 U HIGH_BAND_TUNING_2
9 0 U DUMMY_4
10 0 U DUMMY_5

*END*
*REMARK* SamacSys ECAD Model
1265527/1357656/2.50/10/4/Antenna
